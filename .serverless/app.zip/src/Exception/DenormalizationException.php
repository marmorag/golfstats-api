<?php

namespace App\Exception;


class DenormalizationException extends \Exception
{
}