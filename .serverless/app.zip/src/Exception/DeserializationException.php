<?php

namespace App\Exception;


class DeserializationException extends \Exception{}