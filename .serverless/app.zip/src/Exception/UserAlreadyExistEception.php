<?php

namespace App\Exception;


class UserAlreadyExistEception extends \Exception{}