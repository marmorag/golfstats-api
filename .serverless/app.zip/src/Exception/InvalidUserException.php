<?php

namespace App\Exception;

class InvalidUserException extends \Exception{}